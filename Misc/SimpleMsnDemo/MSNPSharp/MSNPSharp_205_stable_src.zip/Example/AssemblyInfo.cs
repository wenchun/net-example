using System;
using System.Reflection;
using System.Runtime.CompilerServices;
using System.Runtime.InteropServices;

[assembly: ComVisibleAttribute(false)]
[assembly: CLSCompliantAttribute(false)]
[assembly: AssemblyVersionAttribute("2.0.5.*")]
[assembly: AssemblyTitleAttribute("MSNPSharp Example client")]
[assembly: AssemblyDescriptionAttribute(".NET MSN Messenger library Example Client")]
[assembly: AssemblyCopyrightAttribute("Copyright (c) 2002-2008, Bas Geertsema, Xih Solutions (http://www.xihsolutions.net), Thiago.Sayao, Pang Wu, Ethem Evlice.")]
[assembly: AssemblyProductAttribute("MSNPSharp")]
[assembly: AssemblyDelaySignAttribute(false)]
